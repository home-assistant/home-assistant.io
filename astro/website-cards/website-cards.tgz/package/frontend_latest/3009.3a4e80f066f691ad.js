export const __rspack_esm_id=3009;export const __rspack_esm_ids=[3009];export const __webpack_modules__={35609(t,e,i){const o=(0,i(63018).q6)("dirtyState");i.d(e,{},{f:o,v:"__default__"})},30299(t,e,i){i.a(t,async function(t,o){try{i.r(e);i(18111),i(61701);var r=i(28861),s=i(11467),a=i(6267),n=i(5633),l=i(62228),c=i(69595),h=(i(35883),i(44e3)),d=i(25395),_=i(23745),p=i(56757),u=i(7578),g=i(52221),y=i(22854),f=t([c,h,d,g,y]);[c,h,d,g,y]=f.then?(await f)():f;class m extends((0,p.U)()(s.WF)){async showDialog(t){this._entry=t.entry,this._dialogParams=t,this._color=t.initialColor??this._computeCurrentColor(),this._updateModes(),this._open=!0,this._initDirtyTracking({type:"deep"},{color:this._color})}closeDialog(){this._open=!1}_updateModes(){const t=(0,_.ti)(this.stateObj,_.NC.COLOR_TEMP),e=[];(0,_.Aw)(this.stateObj)&&e.push("color"),t&&e.push("color_temp"),this._modes=e,this._color?this._mode="color_temp_kelvin"in this._color?"color_temp":"color":this._mode=this._modes[0]}_computeCurrentColor(){const t=this.stateObj.attributes,e=t.color_mode;let i;return e===_.NC.XY?t.hs_color?i={hs_color:t.hs_color}:t.rgb_color&&(i={rgb_color:t.rgb_color}):e===_.NC.COLOR_TEMP&&t.color_temp_kelvin?i={color_temp_kelvin:t.color_temp_kelvin}:t[e+"_color"]&&(i={[e+"_color"]:t[e+"_color"]}),i}_colorChanged(t){this._color=t.detail,this._updateDirtyState({color:this._color})}get stateObj(){return this._entry&&this.hass.states[this._entry.entity_id]}_dialogClosed(){this._open=!1,this._dialogParams=void 0,this._entry=void 0,this._color=void 0,(0,l.r)(this,"dialog-closed",{dialog:this.localName})}async _save(){this._color?(this._dialogParams?.submit?.(this._color),this._markDirtyStateClean(),this.closeDialog()):this.closeDialog()}_modeChanged(t){const e=t.currentTarget.mode;e!==this._mode&&(this._mode=e)}render(){return this._entry&&this.stateObj?s.qy` <ha-dialog .open=${this._open} .headerTitle=${this._dialogParams?.title} .preventScrimClose=${this.isDirtyState} @closed=${this._dialogClosed}> <div class="header"> ${this._modes.length>1?s.qy` <div class="modes"> ${this._modes.map(t=>s.qy` <ha-icon-button-toggle border-only .selected=${t===this._mode} .label=${this.hass.localize(`ui.dialogs.more_info_control.light.color_picker.mode.${t}`)} .mode=${t} @click=${this._modeChanged}> <span class="wheel ${(0,n.H)({[t]:!0})}"></span> </ha-icon-button-toggle> `)} </div> `:s.s6} </div> <div class="content"> ${"color_temp"===this._mode?s.qy` <light-color-temp-picker .stateObj=${this.stateObj} @color-changed=${this._colorChanged}> </light-color-temp-picker> `:s.s6} ${"color"===this._mode?s.qy` <light-color-rgb-picker .stateObj=${this.stateObj} @color-changed=${this._colorChanged}> </light-color-rgb-picker> `:s.s6} </div> <ha-dialog-footer slot="footer"> <ha-button slot="secondaryAction" appearance="plain" @click=${this.closeDialog}> ${this.hass.localize("ui.common.cancel")} </ha-button> <ha-button slot="primaryAction" @click=${this._save} .disabled=${!this._color}> ${this.hass.localize("ui.common.save")} </ha-button> </ha-dialog-footer> </ha-dialog> `:s.s6}static get styles(){return[u.nA,s.AH`
        ha-dialog {
          --ha-dialog-width-md: 420px; /* prevent width jumps when switching modes */
          --ha-dialog-max-height: min(
            600px,
            100% - 48px
          ); /* prevent scrolling on desktop */
        }

        @media all and (max-width: 450px), all and (max-height: 500px) {
          ha-dialog {
            --ha-dialog-width-md: 100vw;
            --ha-dialog-max-height: calc(100% - 100px);
          }
        }

        .content {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: var(--ha-space-6);
          flex: 1;
        }
        .modes {
          display: flex;
          flex-direction: row;
          justify-content: flex-end;
          padding: 0 var(--ha-space-6);
        }
        .wheel {
          width: 30px;
          height: 30px;
          flex: none;
          border-radius: var(--ha-border-radius-xl);
        }
        .wheel.color {
          background-image: url(${(0,s.iz)(globalThis.__HA_WEBSITE_CARDS_STATIC__)}images/color_wheel.png);
          background-size: cover;
        }
        .wheel.color_temp {
          background: linear-gradient(
            0,
            rgb(166, 209, 255) 0%,
            white 50%,
            rgb(255, 160, 0) 100%
          );
        }
      `]}constructor(...t){super(...t),this._modes=[],this._open=!1}}(0,r.Cg)([(0,a.MZ)({attribute:!1})],m.prototype,"hass",void 0),(0,r.Cg)([(0,a.wk)()],m.prototype,"_dialogParams",void 0),(0,r.Cg)([(0,a.wk)()],m.prototype,"_entry",void 0),(0,r.Cg)([(0,a.wk)()],m.prototype,"_color",void 0),(0,r.Cg)([(0,a.wk)()],m.prototype,"_mode",void 0),(0,r.Cg)([(0,a.wk)()],m.prototype,"_modes",void 0),(0,r.Cg)([(0,a.wk)()],m.prototype,"_open",void 0),m=(0,r.Cg)([(0,a.EM)("dialog-light-color-favorite")],m),o()}catch(t){o(t)}})},56757(t,e,i){i.d(e,{U:()=>_});i(18111),i(13579),i(45367),i(92731);var o=i(28861),r=i(63018),s=i(33810),a=i(6267),n=i(62228),l=i(742);i(17642),i(15024),i(31698);var c=i(35609);const h=new Map,d=()=>{const t=Array.from(h.values()).some(Boolean);t!==window.isDirtyState&&(window.isDirtyState=t,(0,n.r)(window,"dirty-state-changed",{isDirty:t}))},_=()=>t=>{class e extends t{_normalizeEffective(t){return this._effectiveNormalize?this._effectiveNormalize(t):t}_buildContextValue(){const t=Array.from(this._dirtySlices.values());return{isDirty:t.some(({initial:t,current:e})=>!this._dirtyCompareFn(t,e)),isEffectiveDirty:t.some(({normalizedInitial:t,current:e})=>!this._dirtyCompareFn(t,this._normalizeEffective(e))),setState:(t,e)=>{this._writeSlice(e,t)},markClean:()=>{this._markDirtyStateClean()}}}_publishContext(){this._dirtyStateContext=this._buildContextValue()}connectedCallback(){super.connectedCallback(),h.set(this,this.isDirtyState),d()}updated(t){super.updated(t),h.set(this,this.isDirtyState),d()}disconnectedCallback(){h.delete(this),d(),super.disconnectedCallback()}_writeSlice(t,e){const i=this._dirtySlices.get(t);if(!i){const i=this._dirtyCloneFn(e);return this._dirtySlices.set(t,{initial:i,current:e,normalizedInitial:this._normalizeEffective(i)}),void this._publishContext()}this._dirtyCompareFn(i.current,e)||(i.current=e,this._publishContext())}_initDirtyTracking(t,e,i){switch(this._effectiveNormalize=i,t.type){case"deep":this._dirtyCompareFn=(t,e)=>(0,l.b)(t,e),this._dirtyCloneFn=t=>(0,s.A)(t);break;case"shallow":this._dirtyCompareFn=(t,e)=>((t,e)=>{if(t===e)return!0;if(t&&e&&"object"==typeof t&&"object"==typeof e){if(t.constructor!==e.constructor)return!1;let i,o;if(Array.isArray(t)){if(o=t.length,o!==e.length)return!1;for(i=o;0!==i--;)if(t[i]!==e[i])return!1;return!0}if(t instanceof Map&&e instanceof Map){if(t.size!==e.size)return!1;for(i of t.entries())if(!e.has(i[0]))return!1;for(i of t.entries())if(i[1]!==e.get(i[0]))return!1;return!0}if(t instanceof Set&&e instanceof Set){if(t.size!==e.size)return!1;for(i of t.entries())if(!e.has(i[0]))return!1;return!0}if(ArrayBuffer.isView(t)&&ArrayBuffer.isView(e)){if(o=t.length,o!==e.length)return!1;for(i=o;0!==i--;)if(t[i]!==e[i])return!1;return!0}if(t.constructor===RegExp)return t.source===e.source&&t.flags===e.flags;if(t.valueOf!==Object.prototype.valueOf)return t.valueOf()===e.valueOf();if(t.toString!==Object.prototype.toString)return t.toString()===e.toString();const r=Object.keys(t);if(o=r.length,o!==Object.keys(e).length)return!1;for(i=o;0!==i--;)if(!Object.prototype.hasOwnProperty.call(e,r[i]))return!1;for(i=o;0!==i--;){const o=r[i];if(t[o]!==e[o])return!1}return!0}return t!=t&&e!=e})(t,e),this._dirtyCloneFn=t=>t;break;default:this._dirtyCompareFn=t.compare,this._dirtyCloneFn=t=>t}if(this._dirtySlices.clear(),void 0!==e){const t=this._dirtyCloneFn(e);this._dirtySlices.set(c.v,{initial:t,current:e,normalizedInitial:this._normalizeEffective(t)})}this._publishContext()}_updateDirtyState(t){this._writeSlice(c.v,t)}_markDirtyStateClean(){for(const t of this._dirtySlices.values())t.initial=this._dirtyCloneFn(t.current),t.normalizedInitial=this._normalizeEffective(t.initial);this._publishContext()}_discardDirtyStateChanges(){for(const t of this._dirtySlices.values())t.current=this._dirtyCloneFn(t.initial);this._publishContext()}get isDirtyState(){return this._dirtyStateContext.isDirty}get isEffectiveDirtyState(){return this._dirtyStateContext.isEffectiveDirty}constructor(...t){super(...t),this._dirtySlices=new Map,this._dirtyCompareFn=l.b,this._dirtyCloneFn=t=>t,this._dirtyStateContext=this._buildContextValue()}}return(0,o.Cg)([(0,r.Gt)({context:c.f}),(0,a.wk)()],e.prototype,"_dirtyStateContext",void 0),e}}};